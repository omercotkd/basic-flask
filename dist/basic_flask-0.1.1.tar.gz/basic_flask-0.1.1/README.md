# Basic Flask
This packge will allow you to create a basic flask app with a singel commend line.
Simply pip install it and then you can type in the commend line: "create-flask" and 
in the corrent directory a venv will be created with flask and python-dotenv
alredy installed.
On top of that a few files will be created, main.py .gitignore .env .flaskenv requirements.txt 
with some data.
Now you can simply type "flask run" and the flask app will start!
